| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 5.125 ± 0.044 | 5.084 | 5.195 | 1.98 ± 0.03 |
| `rawgrep` | 2.593 ± 0.039 | 2.551 | 2.650 | 1.00 |

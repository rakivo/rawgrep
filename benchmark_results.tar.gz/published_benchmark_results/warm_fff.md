| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 625.0 ± 12.5 | 599.2 | 650.1 | 3.66 ± 0.19 |
| `rawgrep` | 170.5 ± 8.2 | 156.4 | 192.8 | 1.00 |

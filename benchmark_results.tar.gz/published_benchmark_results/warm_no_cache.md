| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `rawgrep (no cache)` | 370.7 ± 6.6 | 357.8 | 387.7 | 1.02 ± 0.03 |
| `ripgrep` | 364.8 ± 7.3 | 349.7 | 387.1 | 1.00 |

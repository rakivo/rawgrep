| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 5.084 ± 0.030 | 5.048 | 5.152 | 1.96 ± 0.03 |
| `rawgrep` | 2.596 ± 0.039 | 2.556 | 2.686 | 1.00 |

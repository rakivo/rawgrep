| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 5.134 ± 0.034 | 5.094 | 5.194 | 1.90 ± 0.02 |
| `rawgrep` | 2.708 ± 0.024 | 2.689 | 2.770 | 1.00 |

| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 5.117 ± 0.021 | 5.083 | 5.156 | 1.98 ± 0.02 |
| `rawgrep` | 2.587 ± 0.031 | 2.562 | 2.668 | 1.00 |

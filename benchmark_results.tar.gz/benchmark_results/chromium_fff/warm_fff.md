| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 622.8 ± 13.1 | 599.8 | 649.1 | 4.87 ± 0.14 |
| `rawgrep` | 127.9 ± 2.3 | 117.4 | 130.2 | 1.00 |

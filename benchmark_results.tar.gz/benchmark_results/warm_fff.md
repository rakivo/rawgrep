| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 625.4 ± 11.1 | 590.1 | 644.2 | 4.46 ± 0.27 |
| `rawgrep` | 140.2 ± 8.1 | 114.8 | 157.8 | 1.00 |

| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 626.8 ± 11.8 | 600.4 | 648.2 | 3.74 ± 0.16 |
| `rawgrep` | 167.6 ± 6.6 | 152.1 | 187.6 | 1.00 |

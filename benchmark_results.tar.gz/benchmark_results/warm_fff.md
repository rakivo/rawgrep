| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 623.4 ± 12.3 | 596.4 | 648.2 | 3.83 ± 0.19 |
| `rawgrep` | 162.6 ± 7.2 | 147.6 | 177.7 | 1.00 |

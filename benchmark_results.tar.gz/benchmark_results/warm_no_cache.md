| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `rawgrep (no cache)` | 330.9 ± 7.0 | 314.6 | 347.9 | 1.00 |
| `ripgrep` | 366.4 ± 6.2 | 354.8 | 382.6 | 1.11 ± 0.03 |

| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `rawgrep (no cache)` | 382.3 ± 5.4 | 371.6 | 396.2 | 1.04 ± 0.02 |
| `ripgrep` | 367.5 ± 6.8 | 356.5 | 382.3 | 1.00 |

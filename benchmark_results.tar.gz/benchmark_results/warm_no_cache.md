| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `rawgrep (no cache)` | 318.3 ± 5.6 | 307.2 | 331.6 | 1.00 |
| `ripgrep` | 363.9 ± 6.5 | 353.6 | 382.8 | 1.14 ± 0.03 |

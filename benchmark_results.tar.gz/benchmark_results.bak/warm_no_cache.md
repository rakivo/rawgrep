| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `rawgrep (no cache)` | 336.7 ± 5.7 | 325.9 | 353.6 | 1.00 |
| `ripgrep` | 366.5 ± 6.4 | 352.0 | 384.7 | 1.09 ± 0.03 |

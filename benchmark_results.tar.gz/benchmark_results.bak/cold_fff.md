| Command | Mean [s] | Min [s] | Max [s] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 5.293 ± 0.024 | 5.267 | 5.344 | 1.50 ± 0.02 |
| `rawgrep` | 3.519 ± 0.035 | 3.461 | 3.563 | 1.00 |

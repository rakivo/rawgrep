| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `fff (cache built once)` | 625.6 ± 13.4 | 586.3 | 646.7 | 3.89 ± 0.27 |
| `rawgrep` | 160.9 ± 10.8 | 141.1 | 248.4 | 1.00 |

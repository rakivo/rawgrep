| Command | Mean [ms] | Min [ms] | Max [ms] | Relative |
|:---|---:|---:|---:|---:|
| `rawgrep (no cache)` | 539.9 ± 5.6 | 526.1 | 555.9 | 1.49 ± 0.03 |
| `ripgrep` | 363.6 ± 6.7 | 351.0 | 383.1 | 1.00 |
